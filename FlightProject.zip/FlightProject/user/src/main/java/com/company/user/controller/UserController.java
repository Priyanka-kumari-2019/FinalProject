package com.company.user.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.user.dto.LoginResponseDto;
import com.company.user.dto.UserRequestDto;
import com.company.user.dto.UserResponseDto;
import com.company.user.service.UserService;

@RestController
public class UserController {

	Logger logger = LoggerFactory.getLogger(UserController.class);

	@Autowired
	UserService userService;

	/* save user details */
	@PostMapping("/users")
	public ResponseEntity<UserResponseDto> registration(@RequestBody UserRequestDto userRequestDto) {
		logger.info("Registering new user");
		return userService.saveUserDetails(userRequestDto);
	}
	

	/*
	 * validate user
	 * 
	 * @Param userId,password
	 * 
	 * @return loginSuccessful message
	 */
	@GetMapping("/users/login")
	public ResponseEntity<LoginResponseDto> validation(@RequestParam long userId, @RequestParam String password) {
		logger.info("Validating the login details of user");
		return userService.validateUser(userId, password);
	}

}
