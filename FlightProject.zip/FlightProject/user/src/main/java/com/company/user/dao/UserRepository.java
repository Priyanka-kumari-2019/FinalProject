package com.company.user.dao;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.company.user.model.User;



@Repository
public interface UserRepository extends CrudRepository<User, Long> { 
	
	/*
	 * @Query("select name from User where userId=?1 and password=?2") public String
	 * validateUser(long userId, String password);
	 */
	
	public User findByIdAndPassword(long id,String password);

}
