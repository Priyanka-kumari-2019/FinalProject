package com.company.user.service;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.company.user.dao.UserRepository;
import com.company.user.dto.LoginResponseDto;
import com.company.user.dto.UserRequestDto;
import com.company.user.dto.UserResponseDto;
import com.company.user.exception.InvalidCredentialsException;
import com.company.user.model.User;
import com.company.user.utility.UserHelperClass;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository userRepository;

	@Autowired
	ModelMapper modelMapper;

	@Override
	public ResponseEntity<UserResponseDto> saveUserDetails(UserRequestDto userRequestDto) {

		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		User user = modelMapper.map(userRequestDto, User.class);
		user.setId(UserHelperClass.generateUserId());

		userRepository.save(user);

		String message = "Successfully Registered";
		HttpStatus statusCode = HttpStatus.OK;
		UserResponseDto response = new UserResponseDto(statusCode.value(), message, user.getId());

		return new ResponseEntity<UserResponseDto>(response, HttpStatus.CREATED);

	}

	@Override
	public ResponseEntity<LoginResponseDto> validateUser(long userId, String password) {
		User validUserDetails = userRepository.findByIdAndPassword(userId, password);

		if (validUserDetails == null)
			throw new InvalidCredentialsException("Invalid Credentials!");
		HttpStatus statusCode = HttpStatus.OK;
		String message = "Successfully logged in";
		LoginResponseDto response = new LoginResponseDto(statusCode.value(), message);
		return new ResponseEntity<LoginResponseDto>(response, HttpStatus.OK);
	}

}
