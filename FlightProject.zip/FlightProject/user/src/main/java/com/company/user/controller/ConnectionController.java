package com.company.user.controller;

import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.company.user.dto.FlightResponseDto;
import com.company.user.dto.TicketBookingReponseDto;
import com.company.user.dto.TicketDetailsResponseDto;
import com.company.user.dto.TicketRequestDto;

@RestController
public class ConnectionController {

	@Autowired
	RestTemplate restTemplate;
	
	/*
	 * Search flights 
	 * 
	 * @Param source,destination,date
	 * 
	 * @return list of flights
	 */
	@GetMapping("/flights")
	public ResponseEntity<List<FlightResponseDto>> searchFlight(@RequestParam(value = "source") String source,
			@RequestParam(value = "destination") String destination, @RequestParam(value = "date") Date date) {

		List<FlightResponseDto> flightDtoList = restTemplate.getForObject("http://flight/flightApp/flights?source=" + source + "&destination=" + destination
						+ "&date=" + date, List.class);

		return new ResponseEntity<List<FlightResponseDto>>(flightDtoList, HttpStatus.OK);
	}

	
	/*
	 * Search flights 
	 * 
	 * @Param source,destination,cost
	 * 
	 * @return list of flights
	 */
	@GetMapping("/flights/cost")
	public ResponseEntity<List<FlightResponseDto>> searchFlight(@RequestParam String source,
			@RequestParam String destination, @RequestParam double economicCost) {
		List<FlightResponseDto> flightDtoList = restTemplate.getForObject("http://flight/flightApp/flights/cost?source=" + source + "&destination="
						+ destination + "&economicCost=" + economicCost, List.class);
		return new ResponseEntity<List<FlightResponseDto>>(flightDtoList, HttpStatus.OK);
	}
	
	
	/*
	 * Filter searched flight by flightName
	 * 
	 * @Param flightName
	 * 
	 * @return list of flights
	 */

	@GetMapping("/flights/flightName")
	public ResponseEntity<List<FlightResponseDto>> filterFlightsByName(@RequestParam String flightName) {

		List<FlightResponseDto> flightDtoList = restTemplate.getForObject("http://flight/flightApp/flights/flightName?flightName=" + flightName, List.class);
		return new ResponseEntity<List<FlightResponseDto>>(flightDtoList, HttpStatus.OK);
	}
	
	/*
	 * Filter searched flight by review
	 * 
	 * @Param flightName
	 * 
	 * @return list of flights
	 */

	
	@GetMapping("/flights/review")
	public ResponseEntity<List<FlightResponseDto>> filterFlights(@RequestParam String review) {

		List<FlightResponseDto> flightDtoList = restTemplate.getForObject("http://flight/flightApp/flights/review?review=" + review, List.class);
		return new ResponseEntity<List<FlightResponseDto>>(flightDtoList, HttpStatus.OK);
	}
	

	/*
	 * book the ticket and save ticketDetails
	 * 
	 * @return ticketId
	 */
	@PostMapping("/tickets")
	public ResponseEntity<TicketBookingReponseDto> bookTickets(@RequestBody TicketRequestDto ticketRequestDto) {
		return restTemplate.postForEntity("http://ticket/ticketApp/tickets", ticketRequestDto, TicketBookingReponseDto.class);

	}
	
	
	/*
	 * get ticket details
	 * 
	 * @path id
	 * 
	 * @return ticket details
	 */

	@GetMapping("/tickets/{id}")
	public ResponseEntity<TicketDetailsResponseDto> getTicketDetails(@PathVariable("id") int ticketId) {
		return restTemplate.getForEntity("http://ticket/ticketApp/tickets/" + ticketId,
				TicketDetailsResponseDto.class);

	}

}
