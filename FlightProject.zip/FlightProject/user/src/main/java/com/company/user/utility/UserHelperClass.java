package com.company.user.utility;

public class UserHelperClass {
	
	static long id=1230001;
	
	public static long generateUserId()
	{
		return id++;
	}

}
