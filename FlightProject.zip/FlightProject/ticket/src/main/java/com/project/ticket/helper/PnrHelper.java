package com.project.ticket.helper;

public class PnrHelper {
	static String pnrNumber;
	static int number=1001; 
	public static String generatePnr(String flightId) {
		pnrNumber=flightId+number;
		number++;
		return pnrNumber;
		
	}

}
