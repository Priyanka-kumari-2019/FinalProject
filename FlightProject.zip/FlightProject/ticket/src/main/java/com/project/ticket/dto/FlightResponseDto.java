package com.project.ticket.dto;

import java.sql.Date;
import java.sql.Time;


public class FlightResponseDto {
	
	private String flightId;
	private String flightName;
	private String type;
	private String source;
	private String destination;
	private Date date;
	private Time departureTime;
	private Time arrivalTime;
	private int businessSeats;
	private double businessCost;
	private int economicSeats;
	private double economicCost;
	
	
	public String getFlightId() {
		return flightId;
	}
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Time getDepartureTime() {
		return departureTime;
	}
	public void setDepartureTime(Time departureTime) {
		this.departureTime = departureTime;
	}
	public Time getArrivalTime() {
		return arrivalTime;
	}
	public void setArrivalTime(Time arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	public int getBusinessSeats() {
		return businessSeats;
	}
	public void setBusinessSeats(int businessSeats) {
		this.businessSeats = businessSeats;
	}
	public double getBusinessCost() {
		return businessCost;
	}
	public void setBusinessCost(double businessCost) {
		this.businessCost = businessCost;
	}
	public int getEconomicSeats() {
		return economicSeats;
	}
	public void setEconomicSeats(int economicSeats) {
		this.economicSeats = economicSeats;
	}
	public double getEconomicCost() {
		return economicCost;
	}
	public void setEconomicCost(double economicCost) {
		this.economicCost = economicCost;
	}
	
	
	

}
