package com.project.ticket.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.project.ticket.dto.TicketBookingReponseDto;
import com.project.ticket.dto.TicketDetailsResponseDto;
import com.project.ticket.dto.TicketRequestDto;
import com.project.ticket.service.TicketService;

@RestController
public class TicketController {
	Logger logger = LoggerFactory.getLogger(TicketController.class);
	@Autowired
	TicketService ticketService;

	/*
	 * book the ticket and save ticketDetails
	 * 
	 * @return ticketId
	 */
	@PostMapping("/tickets")
	public ResponseEntity<TicketBookingReponseDto> bookTickets(@RequestBody TicketRequestDto ticketRequestDto) {
		logger.info("book the ticket");
		return ticketService.bookTicket(ticketRequestDto);

	}

	/*
	 * get ticket details
	 * 
	 * @path id
	 * 
	 * @return ticket details
	 */
	@GetMapping("/tickets/{id}")
	public ResponseEntity<TicketDetailsResponseDto> getTicketDetails(@PathVariable("id") int ticketId) {
		logger.info("show ticket details");
		return ticketService.getTicketDetails(ticketId);

	}

}
