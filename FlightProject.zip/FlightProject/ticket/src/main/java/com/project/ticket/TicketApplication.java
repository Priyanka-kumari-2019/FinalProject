package com.project.ticket;

import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
/*import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;*/
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;

@EnableEurekaClient
@SpringBootApplication
public class TicketApplication {

	private static final Logger logger = LoggerFactory.getLogger(TicketApplication.class);

	public static void main(String[] args) {
		logger.info("this is a info message");
		SpringApplication.run(TicketApplication.class, args);
	}

	@Bean
	public ModelMapper getModelMapper() {
		return new ModelMapper();
	}
	
	
	 @LoadBalanced 
	@Bean
	
	public RestTemplate getRestTemplate() {
		return new RestTemplate();
	}

}
