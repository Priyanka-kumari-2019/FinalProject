package com.project.ticket.dto;

import java.sql.Date;
import java.util.List;

import org.springframework.stereotype.Component;

@Component
public class TicketRequestDto {
	
	private int userId;
	private String flightId;
	private String category;
	private Date date;
	private List<PassengerRequestDto> passengers;
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getFlightId() {
		return flightId;
	}
	public void setFlightId(String flightId) {
		this.flightId = flightId;
	}
	
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public List<PassengerRequestDto> getPassengers() {
		return passengers;
	}
	public void setPassengers(List<PassengerRequestDto> passengers) {
		this.passengers = passengers;
	}
	
	
	
}
