package com.project.ticket.service;

import org.springframework.http.ResponseEntity;

import com.project.ticket.dto.TicketBookingReponseDto;
import com.project.ticket.dto.TicketDetailsResponseDto;
import com.project.ticket.dto.TicketRequestDto;

public interface TicketService {
	
	public ResponseEntity<TicketBookingReponseDto> bookTicket(TicketRequestDto ticketRequestDto) ;
	
	public ResponseEntity<TicketDetailsResponseDto> getTicketDetails(int ticketId);

}
