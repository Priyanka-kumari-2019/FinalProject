package com.project.ticket.dao;

import org.springframework.data.repository.CrudRepository;

import com.project.ticket.model.Ticket;

public interface TicketDao extends CrudRepository<Ticket, Integer>{
	

}
