package com.project.ticket.model;

import java.io.Serializable;

import javax.persistence.Embeddable;

@Embeddable
public class PassengerTicketKey implements Serializable{
	private static final long serialVersionUID = 1L;
	
	private int ticketId;
	private String pnr;
	
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	public String getPnr() {
		return pnr;
	}
	public void setPnr(String pnr) {
		this.pnr = pnr;
	}
	

}
