package com.project.ticket.exception;

public class TicketMaxLimitException extends RuntimeException {

private static final long serialVersionUID = 1L;
	
	public TicketMaxLimitException(String message) {
		
		super(message);
	}

}
