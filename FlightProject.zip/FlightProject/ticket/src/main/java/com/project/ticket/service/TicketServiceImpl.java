package com.project.ticket.service;

import java.util.List;

import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.modelmapper.convention.MatchingStrategies;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.project.ticket.dao.PassengerDao;
import com.project.ticket.dao.TicketDao;

import com.project.ticket.dto.FlightResponseDto;
import com.project.ticket.dto.PassengerRequestDto;
import com.project.ticket.dto.TicketBookingReponseDto;
import com.project.ticket.dto.TicketDetailsResponseDto;
import com.project.ticket.dto.TicketRequestDto;
import com.project.ticket.exception.SeatNotAvailableException;
import com.project.ticket.exception.TicketMaxLimitException;
import com.project.ticket.helper.BookingIdHelper;
import com.project.ticket.helper.PnrHelper;
import com.project.ticket.helper.UpdateSeatsHelper;
import com.project.ticket.model.Passenger;
import com.project.ticket.model.PassengerTicketKey;
import com.project.ticket.model.Ticket;

@Service
public class TicketServiceImpl implements TicketService {

	Logger logger = LoggerFactory.getLogger(TicketService.class);
	@Autowired
	ModelMapper modelMapper;
	@Autowired
	TicketDao ticketDao;
	@Autowired
	PassengerDao passengerDao;

	@Autowired
	RestTemplate restTemplate;

	@Autowired
	UpdateSeatsHelper seatHelper;

	int ticketID;
	String flightId;

	/*
	 * save ticket details in ticket table and passenger details in passenger table
	 */
	@Override
	public ResponseEntity<TicketBookingReponseDto> bookTicket(TicketRequestDto ticketRequestDto) {

		List<PassengerRequestDto> passengerList = ticketRequestDto.getPassengers();
		flightId = ticketRequestDto.getFlightId();
		double totalCost = 0;

		if (passengerList.size() > 3)
			throw new TicketMaxLimitException("Ticket Booking Limit excedded");

		String url = "http://flight/flightApp/flights/" + flightId;

		ResponseEntity<FlightResponseDto> flight = restTemplate.getForEntity(url, FlightResponseDto.class);
		if (ticketRequestDto.getCategory().equalsIgnoreCase("business")) {
			if (flight.getBody().getBusinessSeats() < passengerList.size())
				throw new SeatNotAvailableException("Required number of Seats are not available");
		}

		if (ticketRequestDto.getCategory().equalsIgnoreCase("economic")) {
			if (flight.getBody().getEconomicSeats() < passengerList.size())
				throw new SeatNotAvailableException("Required number of Seats are not available");
		}

		modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);
		Ticket ticket = modelMapper.map(ticketRequestDto, Ticket.class);
		ticketID = BookingIdHelper.generateBookingId();
		ticket.setId(ticketID);
		ticket.setSeats(passengerList.size());

		List<Passenger> passengerDetails = passengerList.stream().map(passenger -> savePassengers(passenger))
				.collect(Collectors.toList());

		if (ticketRequestDto.getCategory().equalsIgnoreCase("business")) {
			totalCost = flight.getBody().getBusinessCost() * passengerList.size();
			int seats = flight.getBody().getBusinessSeats() - passengerList.size();
			seatHelper.updateBusinessSeats(flightId, seats);
		}

		if (ticketRequestDto.getCategory().equalsIgnoreCase("economic")) {
			totalCost = flight.getBody().getEconomicCost() * passengerList.size();
			int seats = flight.getBody().getEconomicSeats() - passengerList.size();
			seatHelper.updateEconomicSeats(flightId, seats);
		}

		ticket.setTotalCost(totalCost);
		ticketDao.save(ticket);
		String message = "Booking Successful";

		TicketBookingReponseDto response = new TicketBookingReponseDto(ticketID, message, HttpStatus.OK.value());

		return new ResponseEntity<TicketBookingReponseDto>(response, HttpStatus.CREATED);
	}
	
	
	/*get the ticket details 
	 * @path ticketId
	 * @return ticketDetails*/

	@Override
	public ResponseEntity<TicketDetailsResponseDto> getTicketDetails(int ticketId) {
		Optional<Ticket> ticket = ticketDao.findById(ticketId);
		String flightId = ticket.get().getFlightId();
		String url = "http://flight/flightApp/flights/" + flightId;

		ResponseEntity<FlightResponseDto> flightDetails = restTemplate.getForEntity(url, FlightResponseDto.class);

		TicketDetailsResponseDto ticketResponseDetails = new TicketDetailsResponseDto();

		ticketResponseDetails.setFlightId(flightDetails.getBody().getFlightId());
		ticketResponseDetails.setFlightName(flightDetails.getBody().getFlightName());
		ticketResponseDetails.setDate(flightDetails.getBody().getDate());
		ticketResponseDetails.setArrivalTime(flightDetails.getBody().getArrivalTime());
		ticketResponseDetails.setDepartureTime(flightDetails.getBody().getDepartureTime());
		ticketResponseDetails.setSource(flightDetails.getBody().getSource());
		ticketResponseDetails.setDestination(flightDetails.getBody().getDestination());
		ticketResponseDetails.setTicketId(ticketId);
		return new ResponseEntity<TicketDetailsResponseDto>(ticketResponseDetails, HttpStatus.OK);

	}

	public Passenger savePassengers(PassengerRequestDto passengerRequestDto) {

		Passenger passenger = modelMapper.map(passengerRequestDto, Passenger.class);
		PassengerTicketKey passengerTicketKey = new PassengerTicketKey();
		passengerTicketKey.setPnr(PnrHelper.generatePnr(flightId));
		passengerTicketKey.setTicketId(ticketID);
		passenger.setPassengerTicketKey(passengerTicketKey);

		Passenger passengerDetails = passengerDao.save(passenger);
		return passengerDetails;

	}

}
