package com.project.ticket.helper;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

@Component

public class UpdateSeatsHelper {

	@Autowired
	RestTemplate restTemplate;

	public ResponseEntity<String> updateBusinessSeats(String flightId, int seats) {
		String url = "http://flight//flightApp/flights/" + flightId + "/updateBusinessSeats/" + seats;
		 ResponseEntity<String> message=restTemplate.getForEntity(url, String.class);
		 return new ResponseEntity<String>(message.getBody(), HttpStatus.OK);

	}

	public ResponseEntity<String> updateEconomicSeats(String flightId, int seats) {
		String url = "http://flight//flightApp/flights/" + flightId + "/updateEconomicSeats/" + seats;
		ResponseEntity<String> message=restTemplate.getForEntity(url, String.class);
		 return new ResponseEntity<String>(message.getBody(), HttpStatus.OK);
		 

	}

}
