package com.project.ticket.helper;

public class BookingIdHelper {
	private static int bookingId=1000;
	public static int generateBookingId() {
		bookingId++;
		return bookingId;
	}
	

}
