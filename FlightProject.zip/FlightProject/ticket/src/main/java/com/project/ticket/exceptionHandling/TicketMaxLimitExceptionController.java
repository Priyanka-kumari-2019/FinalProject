package com.project.ticket.exceptionHandling;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

import com.project.ticket.exception.TicketMaxLimitException;

@ControllerAdvice
public class TicketMaxLimitExceptionController extends ResponseEntityExceptionHandler {

	@ExceptionHandler(TicketMaxLimitException.class)
	public ResponseEntity<Error> handleException(TicketMaxLimitException exception) {

		Error error = new Error();
		error.setMessage(exception.getMessage());
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setTimeStamp(LocalDateTime.now());
		error.setSuggestion("sorry,You can't book for more than 3 passengers");
		return new ResponseEntity<Error>(error, HttpStatus.NOT_FOUND);
	}

}
