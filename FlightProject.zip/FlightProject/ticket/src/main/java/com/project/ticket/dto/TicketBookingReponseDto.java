package com.project.ticket.dto;


public class TicketBookingReponseDto {
	int ticketId;
	String message;
	int statusCode;

	public TicketBookingReponseDto(int ticketId, String message, int statusCode) {
	
		this.ticketId = ticketId;
		this.message = message;
		this.statusCode = statusCode;
	}

	public int getTicketId() {
		return ticketId;
	}

	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public int getStatusCode() {
		return statusCode;
	}

	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}

}
