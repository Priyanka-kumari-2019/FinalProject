package com.company.flight.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Review {
	@Id
	private String flightName;
	private String review;
	
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}
	
	
}
