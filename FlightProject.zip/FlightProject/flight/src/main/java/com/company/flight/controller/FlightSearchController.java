package com.company.flight.controller;

import java.sql.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.company.flight.dto.FlightResponseDto;
import com.company.flight.service.CategoryService;
import com.company.flight.service.FlightSearchService;

@RestController
public class FlightSearchController {
	Logger logger = LoggerFactory.getLogger(FlightSearchController.class);

	@Autowired
	FlightSearchService flightSearchService;

	@Autowired
	CategoryService categoryService;

	/*
	 * Search flights 
	 * 
	 * @Param source,destination,date
	 * 
	 * @return list of flights
	 */

	@GetMapping("/flights")
	public ResponseEntity<List<FlightResponseDto>> searchFlight(@RequestParam(value = "source") String source,
			@RequestParam(value = "destination") String destination, @RequestParam(value = "date") Date date) {
		logger.info("searching flights by source ,destination and date");
		return flightSearchService.getFlights(source, destination, date);
	}

	/*
	 * Search flights 
	 * 
	 * @Param source,destination,cost
	 * 
	 * @return list of flights
	 */

	@GetMapping("/flights/cost")
	public ResponseEntity<List<FlightResponseDto>> searchFlight(@RequestParam String source, @RequestParam String destination,
			@RequestParam double economicCost) {
		logger.info("searching flights by source ,destination and cost");
		return flightSearchService.getFlights(source, destination, economicCost);

	}

	/*
	 * Filter searched flight by flightName
	 * 
	 * @Param flightName
	 * 
	 * @return list of flights
	 */

	@GetMapping("/flights/flightName")
	public ResponseEntity<List<FlightResponseDto>> filterFlight(@RequestParam String flightName) {
		logger.info("filtering flights by flightName");

		return flightSearchService.getFlights(flightName);

	}
	
	

	
	
	  @GetMapping("/flights/review") 
	  public ResponseEntity<List<FlightResponseDto>> filterFlights(@RequestParam String review) {
	  logger.info("filtering flights by review");
	  
	  return flightSearchService.filterFlights(review); }
	 
	 
	
	
	/*
	 * Get flight by flightId
	 * 
	 * @Path flightId
	 * 
	 * @return flight details
	 */

	@GetMapping("/flights/{id}")
	public ResponseEntity<FlightResponseDto> getFlightDetailsById(@PathVariable("id") String flightId) {
		logger.info("getting flights by flightId");
		return flightSearchService.getFlight(flightId);
	}
	
	
	
	/*update business seats after booting the ticket*/

	@GetMapping("/flights/{id}/updateBusinessSeats/{seats}")
	public ResponseEntity<String> updateBusinessSeats(@PathVariable("id") String categoryId,
			@PathVariable("seats") int seats) {
		categoryService.updateBusinessSeats(categoryId, seats);
		return new ResponseEntity<String>("seats updated successfully ", HttpStatus.OK);

	}
	
	
	/*update economic seats after booting the ticket*/

	@GetMapping("/flights/{id}/updateEconomicSeats/{seats}")
	public ResponseEntity<String> updateEconomicSeats(@PathVariable("id") String categoryId,
			@PathVariable("seats") int seats) {
		categoryService.updateEconomicSeats(categoryId, seats);
		return new ResponseEntity<String>("seats updated successfully ", HttpStatus.OK);

	}

}
