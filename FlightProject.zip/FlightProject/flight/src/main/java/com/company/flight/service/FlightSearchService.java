package com.company.flight.service;

import java.sql.Date;
import java.util.List;

import org.springframework.http.ResponseEntity;

import com.company.flight.dto.FlightResponseDto;
import com.company.flight.model.Flight;

public interface FlightSearchService {
	
	
	public  ResponseEntity<List<FlightResponseDto>> getFlights(String source,String destination,Date date);
	
	public ResponseEntity<List<FlightResponseDto>> getFlights(String source,String destination,double economicCost);
	
	public ResponseEntity<List<FlightResponseDto>> getFlights(String flightName);
	
	public ResponseEntity<List<FlightResponseDto>> filterFlights(String review);
	
	public ResponseEntity<FlightResponseDto> getFlight(String flightId);
	
	
	
	
}
