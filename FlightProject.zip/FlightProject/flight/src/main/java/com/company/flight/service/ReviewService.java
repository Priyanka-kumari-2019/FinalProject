package com.company.flight.service;

import java.util.List;


import com.company.flight.model.Flight;
import com.company.flight.model.Review;

public interface ReviewService {
	
	public List<Review> getAllReviewDetails(List<Flight> flightList);

}
