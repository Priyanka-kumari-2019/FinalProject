package com.company.flight.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.company.flight.model.Category;
import com.company.flight.model.Flight;

public interface CategoryService {
	
	public List<Category> getAllCategoryDetails(List<Flight> flightList);
	public ResponseEntity<String> updateBusinessSeats(String categoryId,int seats);
	public ResponseEntity<String> updateEconomicSeats(String categoryId,int seats);
	

}
