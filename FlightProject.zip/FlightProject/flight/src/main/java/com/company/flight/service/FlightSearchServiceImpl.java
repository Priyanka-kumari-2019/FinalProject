package com.company.flight.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.company.flight.dao.CategoryRespository;
import com.company.flight.dao.FlightRepository;
import com.company.flight.dao.ReviewRepository;
import com.company.flight.dto.FlightResponseDto;
import com.company.flight.exception.FlightNotFoundException;
import com.company.flight.model.Category;
import com.company.flight.model.Flight;
import com.company.flight.model.Review;

@Service
public class FlightSearchServiceImpl implements FlightSearchService {

	@Autowired
	FlightRepository flightRepository;

	@Autowired
	CategoryRespository categoryRespository;

	@Autowired
	CategoryService categoryService;
	
	@Autowired
	ReviewService reviewService;
	
	@Autowired
	ReviewRepository reviewRepository;

	@Autowired
	ModelMapper modelMapper;

	List<Flight> flightList = new ArrayList<Flight>();
	List<FlightResponseDto> flightResponseList = new ArrayList<>();

	String flightId;
	String flightName;
	FlightResponseDto flightResponse;

	@Override
	public ResponseEntity<List<FlightResponseDto>> getFlights(String source, String destination, Date date) {

		flightResponseList.clear();

		flightList = flightRepository.findBySourceAndDestinationAndDate(source, destination, date);
		if (flightList.isEmpty())
			throw new FlightNotFoundException("No Flights Available!");

		flightResponseList = flightList.stream().map(flight -> getFlights(flight)).collect(Collectors.toList());
		
		

		return new ResponseEntity<List<FlightResponseDto>>(flightResponseList, HttpStatus.OK);

	}

	@Override
	public ResponseEntity<List<FlightResponseDto>> getFlights(String source, String destination, double economicCost) {

		flightResponseList.clear();

		flightList = flightRepository.getFlights(source, destination, economicCost);

		if (flightList.isEmpty())
			throw new FlightNotFoundException("No Flights Available!");

		flightResponseList = flightList.stream().map(flight -> getFlights(flight)).collect(Collectors.toList());

		return new ResponseEntity<List<FlightResponseDto>>(flightResponseList, HttpStatus.OK);
	}

	@Override
	public ResponseEntity<List<FlightResponseDto>> getFlights(String flightName) {

		List<FlightResponseDto> flightsList = flightResponseList.stream()
				.filter(flight1 -> flight1.getFlightName().equalsIgnoreCase(flightName)).collect(Collectors.toList());
		if (flightsList.isEmpty())
			throw new FlightNotFoundException("No Flights Available!");
		else {
			return new ResponseEntity<List<FlightResponseDto>>(flightsList, HttpStatus.OK);
		}
	}
	
	
	  @Override public ResponseEntity<List<FlightResponseDto>> filterFlights(String review) { 
		  List<FlightResponseDto> flightsList = flightResponseList.stream()
					.filter(flight1 -> flight1.getReview().equalsIgnoreCase(review)).collect(Collectors.toList());
			if (flightsList.isEmpty())
				throw new FlightNotFoundException("No Flights Available!");
			else {
				return new ResponseEntity<List<FlightResponseDto>>(flightsList, HttpStatus.OK);
			}
	  }
	 


	@Override
	public ResponseEntity<FlightResponseDto> getFlight(String flightID) {
		Optional<Flight> flightDetails = flightRepository.findById(flightID);
		Optional<Category> category = categoryRespository.findById(flightID);
		String flightname=flightDetails.get().getFlightName();
		Optional<Review> review=reviewRepository.findById(flightname);
		
		if (!flightDetails.isPresent())
			throw new FlightNotFoundException("No Flights Available with this id");

		Flight flight = flightDetails.get();
		FlightResponseDto flightResponse = modelMapper.map(flight, FlightResponseDto.class);
		flightResponse.setBusinessSeats(category.get().getBusinessSeats());
		flightResponse.setBusinessCost(category.get().getBusinessCost());
		flightResponse.setEconomicSeats(category.get().getEconomicSeats());
		flightResponse.setEconomicCost(category.get().getEconomicCost());
		flightResponse.setReview(review.get().getReview());

		return new ResponseEntity<FlightResponseDto>(flightResponse, HttpStatus.OK);

	}
	
	
	

	public FlightResponseDto getFlights(Flight flight) {
		flightId = flight.getFlightId();
		flightName=flight.getFlightName();
		List<Category> categoryList = categoryService.getAllCategoryDetails(flightList);
		flightResponse = modelMapper.map(flight, FlightResponseDto.class);
	categoryList.stream().map(category -> getCategory(category)).collect(Collectors.toList());
		
		
		List<Review> reviewList=reviewService.getAllReviewDetails(flightList);
		reviewList.stream().map(review-> getReview(review)).collect(Collectors.toList());
		return flightResponse;

	}

	public FlightResponseDto getCategory(Category category) {

		if (flightId.equalsIgnoreCase(category.getId())) {

			flightResponse.setEconomicSeats(category.getEconomicSeats());
			flightResponse.setEconomicCost(category.getEconomicCost());
			flightResponse.setBusinessSeats(category.getBusinessSeats());
			flightResponse.setBusinessCost(category.getBusinessCost());
			
		}
		
		return flightResponse;

	}
	
	public FlightResponseDto getReview(Review review) {

		if (flightName.equalsIgnoreCase(review.getFlightName())) {

			flightResponse.setReview(review.getReview());
				
		}
		
		return flightResponse;

	}

	
	
}
