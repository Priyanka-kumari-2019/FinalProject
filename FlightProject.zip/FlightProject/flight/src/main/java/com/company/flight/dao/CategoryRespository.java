package com.company.flight.dao;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import org.springframework.stereotype.Repository;

import com.company.flight.model.Category;

@Repository
@Transactional
public interface CategoryRespository extends CrudRepository<Category, String> {
	@Modifying
	@Query("update Category cat set cat.businessSeats = ?2 where cat.id = ?1 ")
	public int updateBusinessSeat(String categoryId,Integer seats);
	
	@Modifying
	@Query("update Category cat set cat.economicSeats = ?2 where cat.id = ?1 ")
	public int updateEconomicSeat(String categoryId,Integer seats);

}
