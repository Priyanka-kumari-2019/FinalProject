package com.company.flight.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.company.flight.dao.CategoryRespository;
import com.company.flight.model.Category;
import com.company.flight.model.Flight;

@Service
public class CategoryServiceImpl implements CategoryService {

	@Autowired
	CategoryRespository categoryRespository;

	@Override
	public List<Category> getAllCategoryDetails(List<Flight> flightList) {

		List<String> flightIdList = new ArrayList<String>();

		for (Flight flight : flightList) {
			flightIdList.add(flight.getFlightId());
		}

		List<Category> categoryList = (List<Category>) categoryRespository.findAllById(flightIdList);

		return categoryList;

	}

	@Override
	public ResponseEntity<String> updateBusinessSeats(String categoryId, int seats) {
		int updatedRows = categoryRespository.updateBusinessSeat(categoryId, seats);
		return new ResponseEntity<String>("seats updated successfully ", HttpStatus.OK);
	}

	@Override
	public ResponseEntity<String> updateEconomicSeats(String categoryId, int seats) {
		int updatedRows = categoryRespository.updateEconomicSeat(categoryId, seats);
		return new ResponseEntity<String>("seats updated successfully ", HttpStatus.OK);
	}

}
