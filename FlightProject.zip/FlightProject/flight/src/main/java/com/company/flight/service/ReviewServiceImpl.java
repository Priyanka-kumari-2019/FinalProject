package com.company.flight.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.company.flight.dao.ReviewRepository;

import com.company.flight.model.Flight;
import com.company.flight.model.Review;

@Service
public class ReviewServiceImpl implements ReviewService {
	@Autowired
	ReviewRepository reviewRepository;

	@Override
	public List<Review> getAllReviewDetails(List<Flight> flightList) {
		List<String> flightIdList = new ArrayList<String>();

		for (Flight flight : flightList) {
			flightIdList.add(flight.getFlightName());
		}

		List<Review> reviewList = (List<Review>) reviewRepository.findAllById(flightIdList);

		return reviewList;

	}

}
